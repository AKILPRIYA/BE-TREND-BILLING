module.exports = app => {
    const quantity = require("../controllers/quantity.controller.js");
    const sql = require("../models/db.js");
    var router4 = require("express").Router();
    
    // Create a new Tutorial
    router4.post("/", quantity.create);
    router4.post("/post", quantity.createone);
    // Retrieve all Tutorials
    router4.get("/", quantity.findAll);
  
    // Retrieve all published Tutorials
    router4.get("/published", quantity.findAllPublished);
  
    // Retrieve a single Tutorial with id
    router4.get("/:id/:id1/:id2", quantity.findOne);
    router4.get("/:id", quantity.find);
    router4.post('/add', (req, res) => {
      const { idMRP } = req.body; // Extracting `idMRP` from the request body
      
      if (!idMRP) {
        return res.status(400).send({ message: 'idMRP is required' });
      }
    
      // Insert query
      const query = 'INSERT INTO quantity (idMRP, QUANTITY) VALUES (?, 0)';
    
      // Executing the query with the provided `idMRP`
      sql.query(query, [idMRP], (err, result) => {
        if (err) {
          if (err.code === 'ER_DUP_ENTRY') {
            return res.status(400).json({ message: 'Duplicate MRP for this quantity' });
          }
          console.log("error: ", err);
          return res.status(500).json({ message: 'An error occurred' });
        }
    
        // Send the newly inserted idQUANTITY and success message
        res.status(201).json({ idQUANTITY: result.insertId, message: 'QUANTITY added successfully' });
      });
    });
    
  
    // Update a Tutorial with id
    router4.put("/:id", quantity.update);
    router4.patch("/", (req,res)=>{
      try{
      const products=req.body.rowsData;
      const sum1 = req.body.sum1;
      const name = req.body.name;
      const phone = req.body.phone;
     console.log(sum1);
      if (!products || !Array.isArray(products) || products.length === 0 ||  !sum1) {
        console.error('Invalid request data', { products, sum1 });
        return res.status(400).send('Invalid request data');
    }  sql.beginTransaction((transactionErr) => {
        if (transactionErr) {
            return res.status(500).json({ error: 'Internal Server Error' });
        }
      const billsql = 'INSERT INTO billid (SALESDATE,BILLAMOUNT,NAME,PHONENO) values(NOW(),?,?,?)';
      sql.query(billsql,[sum1,name,phone],(billErr,result)=>{
        if (billErr) {
            return sql.rollback(() => { res.status(500).json({ error: 'Internal Server Error' });
        })}
        const billid = result.insertId;
        const productValues = products.map(product =>[billid,product.idquantity]);
        const productsql = 'INSERT INTO billproducts(idBILL,idQUANTITY) VALUES ?';
        sql.query(productsql,[productValues],(productErr,result)=>{
            if (productErr) {
                return sql.rollback(() => { res.status(500).json({ error: 'Internal Server Error' });
            })}
    const idQUANTITIES = products.map(product => product.idquantity);
    // Check for null or undefined values
    if (idQUANTITIES.some(id => id === null || id === undefined)) {
        return sql.rollback(() => { res.status(400).json({ error: 'Invalid product ID detected (null or undefined)' });
    })};

    const placeholders = idQUANTITIES.map(() => '?').join(',');
    const selectQuery = `SELECT idQUANTITY, QUANTITY FROM quantity WHERE idQUANTITY IN (${placeholders})`;

    sql.query(selectQuery, idQUANTITIES, (selectErr, results) => {
        if (selectErr) {
            return sql.rollback(() => { res.status(500).json({ error: 'Internal Server Error' });
        })}
        const zeroQuantities = results.filter(item => item.QUANTITY === 0);

        if (zeroQuantities.length > 0) {
            return sql.rollback(() => { res.status(400).json({ error: 'Some quantities are 0', zeroQuantities });
            console.log(res.data);
        })}
const updateQueries = results.map(result =>{
    if (!result.idQUANTITY) {
        return Promise.resolve(); // Skip if idQUANTITY is not defined
    }
    const count = products.filter(product => product.idquantity === result.idQUANTITY).length;
    
    return new Promise((resolve, reject)=> {
        const updateQuery = `
      UPDATE quantity
                            SET QUANTITY = QUANTITY - ?
                            WHERE idQUANTITY = ? AND QUANTITY >= ?
                        `;

    sql.query(updateQuery, [count,result.idQUANTITY,count], (updateErr, updateResult) => {
        if (updateErr) {
            reject(updateErr);
        }else{
            resolve(updateResult);
        }
    });
    })   }); Promise.all(updateQueries)
    .then(() => {
        sql.commit((commitErr) => {
            if (commitErr) {
                return sql.rollback(() => {
                    res.status(500).json({ error: 'Internal Server Error' });
                });
            } console.log('Sending success response');
            res.status(200).json({ message: 'Quantity updated successfully',products ,sum1,name,phone});
            console.log(products);
        });
    })
.catch((updateErr) => {
    sql.rollback(() =>{
        res.status(500).json({ error: 'Internal Server Error' });
    });
   
});});
});

});    
     }); }
      catch (err) {
      console.error('Unexpected error:', err);
      res.status(500).send('Unexpected error');
  }});
  router4.patch("/add", (req, res) => {
    const products = req.body.rowsData;
  
    if (!products || !Array.isArray(products) || products.length === 0) {
      console.error('Invalid request data', { products });
      return res.status(400).send('Invalid request data');
    }
  
    // Begin the transaction
    sql.beginTransaction((transactionErr) => {
      if (transactionErr) {
        return res.status(500).json({ error: 'Failed to start transaction' });
      }
  
      // Insert into purchasedate for each product
      const insertPromises = products.map((product) => {
        const { purchaseamount, idquantity } = product;
        const productSql = 'INSERT INTO purchasedate(purchaseDate, purchaseamount, idQUANTITY) VALUES (NOW(), ?, ?)';
  
        return new Promise((resolve, reject) => {
          sql.query(productSql, [purchaseamount, idquantity], (err, result) => {
            if (err) {
              return reject(err);
            }
            resolve(result);
          });
        });
      });
  
      // Execute all insertions in parallel
      Promise.all(insertPromises)
        .then(() => {
          // Now, for each product, update the quantity
          const updatePromises = products.map((product) => {
            const { idquantity } = product;
            const updateSql = 'UPDATE quantity SET QUANTITY = QUANTITY + 1 WHERE idQUANTITY = ?';
  
            return new Promise((resolve, reject) => {
              sql.query(updateSql, [idquantity], (err, result) => {
                if (err) {
                  return reject(err);
                }
                if (result.affectedRows === 0) {
                  return reject(new Error(`Quantity not found for idQUANTITY: ${idquantity}`));
                }
                resolve(result);
              });
            });
          });
  
          // Execute all updates in parallel
          return Promise.all(updatePromises);
        })
        .then(() => {
          // If everything went well, commit the transaction
          sql.commit((commitErr) => {
            if (commitErr) {
              return sql.rollback(() => {
                return res.status(500).json({ error: 'Failed to commit transaction' });
              });
            }
            res.status(200).json({ message: 'Products added and quantities updated successfully' });
          });
        })
        .catch((error) => {
          // Rollback the transaction if any error occurs
          sql.rollback(() => {
            console.error('Transaction failed:', error);
            res.status(500).json({ error: 'Transaction failed', details: error.message });
          });
        });
    });
  });
  
  
    // Delete a Tutorial with id
    router4.delete("/:id", quantity.delete);
  
    // Delete all Tutorials
    router4.delete("/", quantity.deleteAll);
  
    app.use('/api/quantity', router4);
  };
  