module.exports = app => {
    const colour = require("../controllers/colour.controller.js");
  
    var router = require("express").Router();
    
    // Create a new Tutorial
    router.post("/post", (req,res)=>{
      const COLOUR = req.body.COLOUR;
      const sql=require("../models/db.js");
      const query = "INSERT INTO colour (COLOUR) VALUES (?)";
      
      sql.query(query, [COLOUR], (err, result) => {
        if (err) {
          console.error("Error inserting article:", err);
          return res.status(500).json({ message: "Internal Server Error" });
        }
        // Return the inserted article's ID
        res.status(201).json({ idCOLOUR: result.insertId, message: "COLOUR created successfully" });
    });});
  
    // Retrieve all Tutorials
    router.get("/", colour.findAll);
  
    // Retrieve all published Tutorials
    router.get("/published", colour.findAllPublished);
  
    // Retrieve a single Tutorial with id
    router.get("/:id", colour.findOne);
    router.get("/Colour/:id", colour.findOne1);
    // Update a Tutorial with id
    router.put("/:id", colour.update);
  
    // Delete a Tutorial with id
    router.delete("/:id", colour.delete);
  
    // Delete all Tutorials
    router.delete("/", colour.deleteAll);
  
    app.use('/api/colour', router);
  };
  