module.exports = app => {
    const size = require("../controllers/size.controller.js");
  
    var router2 = require("express").Router();
    
    // Create a new Tutorial
    router2.post("/post",async (req,res)=>{
      const idARTICLE = req.body.selectedArticle;
      const SIZE=req.body.SIZE;
      const idCOLOUR = req.body.selectedColour;
      const QUANTITY=req.body.QUANTITY;
      const MRP = req.body.MRP;
      const sql = require("../models/db.js");
      try{
        const [existingEntry] = await db.query(
          'SELECT * FROM size WHERE idARTICLE = ? AND idCOLOUR = ? AND SIZE = ?',
          [idARTICLE, idCOLOUR, SIZE]
        );
    
        if (existingEntry) {
          // If the entry exists, return a 400 error
          return res.status(400).json({ message: 'Duplicate entry: Size already exists' });
        }
     else{   sql.query(
    `INSERT INTO  size(SIZE,idARTICLE,idCOLOUR) values(?,?,?)`,[SIZE,idARTICLE,idCOLOUR], (err, result) => {
      if (err) {
        console.log("error: ", err);
        res.send(err, null);
        return;}sql.query(
    `insert into quantity(QUANTITY,idSIZE) values (?,LAST_INSERT_ID())`,[QUANTITY], (err, result) => {
      if (err) {
        console.log("error: ", err);
        res.send(err, null);
        return;}sql.query(
    `insert into mrp(MRP,idQUANTITY) values (?,LAST_INSERT_ID())`,[MRP], (err, result) => {
      if (err) {
        console.log("error: ", err);
        res.send(err, null);
        return;}
        res.send("POSTED");
  })})});res.status(201).json({ message: 'Size added successfully' });}}
  catch (error) {
    if (error.code === 'ER_DUP_ENTRY') {
        res.status(400).json({ message: 'Duplicate size for this article and colour' });
    } else {
        res.status(500).json({ message: 'An error occurred' });
    }
}})
router2.post('/post1', (req, res) => {
  const { idARTICLE, idCOLOUR, SIZE } = req.body;
  const sql = require("../models/db.js");

  if (!idARTICLE || !idCOLOUR || !SIZE) {
    return res.status(400).json({ message: "Missing required fields" });
  }

  const query = "INSERT INTO size (SIZE, idARTICLE, idCOLOUR) VALUES (?, ?, ?)";
  sql.query(query, [SIZE, idARTICLE, idCOLOUR], (err, result) => {
    if (err) {
      console.error("Error inserting size:", err);
      return res.status(500).json({ message: "Internal Server Error" });
    }

    res.status(201).json({ idSIZE: result.insertId, message: "Size added successfully" });
  });
});


    // Retrieve all Tutorials
    router2.get("/", size.findAll);
  
    // Retrieve all published Tutorials
    router2.get("/published", size.findAllPublished);
  
    // Retrieve a single Tutorial with id
    router2.get("/:id", size.findOne);
    router2.get("/:id/:id1", size.findOnebyid);
    router2.get("/:id/:id1/:id2", size.findOnebyid1);
    
  
    // Update a Tutorial with id
    router2.put("/:id", size.update);
  
    // Delete a Tutorial with id
    router2.delete("/:id", size.delete);
  
    // Delete all Tutorials
    router2.delete("/", size.deleteAll);
  
    app.use('/api/size', router2);
  };
  