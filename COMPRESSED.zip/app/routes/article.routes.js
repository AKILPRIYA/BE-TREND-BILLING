module.exports = app => {
    const article = require("../controllers/article.controller.js");
  
    var router1 = require("express").Router();
    const sql = require("../models/db.js");
    router1.post('/post1', (req, res) => {
      const { ARTICLE, idBRAND } = req.body;
    
      // Check if the article already exists
      sql.query('SELECT * FROM article WHERE ARTICLE = ? AND idBRAND = ?', [ARTICLE, idBRAND], (err, results) => {
        
    
        if (results.length > 0) {
          // Article already exists
          return res.status(400).json({ message: 'Duplicate entry: Article already exists' });
        }
    
        // If the article does not exist, proceed with insertion
        sql.query('INSERT INTO article (ARTICLE, idBRAND) VALUES (?, ?)', [ARTICLE, idBRAND], (err, result) => {
          if (err) {
            console.error('Error inserting article:', err);
            return res.status(500).json({ message: 'Internal Server Error' });
          }
    
          res.status(201).json({ idARTICLE: result.insertId, message: 'Article added successfully' });
        });
      });
    });
    
    
    // Create a new Tutorial
    router1.post("/post", async(req,res)=>{
      const ARTICLE = req.body.ARTICLE;
      const idBRAND = req.body.selectedBrand;
      const SIZE=req.body.SIZE;
      const idCOLOUR = req.body.selectedColour;
      const QUANTITY=req.body.QUANTITY;
      const MRP = req.body.MRP;
      const sql = require("../models/db.js");
      try{
        const [existingEntry] = await db.query(
          'SELECT * FROM article WHERE idBRAND = ? ARTICLE = ?',
          [idBRAND, ARTICLE]
        );
    
        if (existingEntry) {
          // If the entry exists, return a 400 error
          return res.status(400).json({ message: 'Duplicate entry: Size already exists' });
        }else{
      sql.query(`INSERT INTO article(ARTICLE,idBRAND) values(?,?);`, [ARTICLE,idBRAND],
       (err, result) => {
        if (err) {
          console.log("error: ", err);
          res.send(err, null);
          return;}
          sql.query(
    `INSERT INTO  size(SIZE,idARTICLE,idCOLOUR) values(?,LAST_INSERT_ID(),?)`,[SIZE,idCOLOUR], (err, result) => {
      if (err) {
        console.log("error: ", err);
        res.send(err, null);
        return;}sql.query(
    `insert into quantity(QUANTITY,idSIZE) values (?,LAST_INSERT_ID())`,[QUANTITY], (err, result) => {
      if (err) {
        console.log("error: ", err);
        res.send(err, null);
        return;}sql.query(
    `insert into mrp(MRP,idQUANTITY) values (?,LAST_INSERT_ID())`,[MRP], (err, result) => {
      if (err) {
        console.log("error: ", err);
        res.send(err, null);
        return;}
        res.send("POSTED");
  })})})});}res.status(201).json({ message: 'Size added successfully' });}
  catch (error) {
    if (error.code === 'ER_DUP_ENTRY') {
        res.status(400).json({ message: 'Duplicate size for this article and colour' });
    } else {
        res.status(500).json({ message: 'An error occurred' });
    }
}
})
  
    // Retrieve all Tutorials
    router1.get("/", article.findAll);
  
    // Retrieve all published Tutorials
    router1.get("/published", article.findAllPublished);
  
    // Retrieve a single Tutorial with id
    router1.get("/:id", article.findOne);

    router1.get("/brand/:id",article.findByBrandId)
    router1.get("/brand/:id/:article/:size/:colour",article.findByBrandIdAndSize)
    router1.get("/brand/:id/:article/:colour/:size",article.findByBrandIdAndColour)
    router1.get("/brand/:id/:article",article.findByBrandIdAndArticle)
    router1.get("/brand1/:id/:article",article.findByBrandIdAndArticle1)
    // Update a Tutorial with id
    router1.put("/brand/:id", article.update);
  
    // Delete a Tutorial with id
    router1.delete("/:id", article.delete);
  
    // Delete all Tutorials
    router1.delete("/", article.deleteAll);
  
    app.use('/api/article', router1);
  };
  