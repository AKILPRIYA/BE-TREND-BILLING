module.exports = app => {
    const mrp = require("../controllers/mrp.controller.js");
  
    var router5 = require("express").Router();
    
    // Create a new Tutorial
    router5.post("/", mrp.create);
  
    // Retrieve all Tutorials
    router5.get("/", mrp.findAll);
    router5.post("/post1", async (req, res) => {
      const idSIZE = req.body.idSIZE;
      const MRP = req.body.MRP;
      const sql = require("../models/db.js");
      const query = "INSERT INTO mrp (MRP, idSIZE) VALUES (?, ?)";
      
      sql.query(query, [MRP, idSIZE], (err, result) => {
        if (err) {
          console.error("Error inserting article:", err);
          return res.status(500).json({ message: "Internal Server Error" });
        }
        // Return the inserted article's ID
        res.status(201).json({ idMRP: result.insertId, message: "Article created successfully" });
      });
    });
    
    // Retrieve all published Tutorials
    router5.get("/published", mrp.findAllPublished);
  
    // Retrieve a single Tutorial with id
    router5.get("/:id", mrp.findOne);
    router5.get("/:id/:id1", mrp.findOne1);
    // Update a Tutorial with id
    router5.put("/:id", mrp.update);
  
    // Delete a Tutorial with id
    router5.delete("/:id", mrp.delete);
  
    // Delete all Tutorials
    router5.delete("/", mrp.deleteAll);
  
    app.use('/api/mrp', router5);
  };
  