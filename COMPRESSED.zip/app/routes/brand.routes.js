const { findByBrandId } = require("../controllers/article.controller.js");

module.exports = app => {
    const brand = require("../controllers/brand.controller.js");
  
    var router = require("express").Router();
    console.log("1st");
    
    // Create a new Tutorial
    router.post("/post", (req, res) => {
      const { BRAND } = req.body;
      const sql = require("../models/db.js");
    
      const query = "INSERT INTO brand (BRAND) VALUES (?)";
      
      sql.query(query, [BRAND], (err, result) => {
        if (err) {
          console.error("Error inserting article:", err);
          return res.status(500).json({ message: "Internal Server Error" });
        }
        // Return the inserted article's ID
        res.status(201).json({ idBRAND: result.insertId, message: "BRAND created successfully" });
      });
    })

      
    // Retrieve all Tutorials
    router.get("/", brand.findAll);
    
  
    // Retrieve all published Tutorials
    router.get("/published", brand.findAllPublished);
  
    // Retrieve a single Tutorial with id
    router.get("/:id", brand.findOne);
  router.get("/BRAND/:id",brand.findOne1);
    // Update a Tutorial with id
    router.put("/:id", brand.update);
  
    // Delete a Tutorial with id
    router.delete("/:id", brand.delete);
  
    // Delete all Tutorials
    router.delete("/", brand.deleteAll);
  
    app.use('/api/brand', router);
  };
  