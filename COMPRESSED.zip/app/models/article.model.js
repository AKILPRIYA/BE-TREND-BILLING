
const sql = require("./db.js");
// constructor


// constructor
const Tutorial = function(article) {
  this.idARTICLE=article.idARTICLE;
  this.ARTICLE = article.ARTICLE;
  this.idBRAND = article.idBRAND ;
};
const Tutorial1 = function(brand) {
    this.idBrand = brand.idBRAND;
}
Tutorial.create = (article1, result) => {
  sql.query(`INSERT INTO article(ARTICLE,idBRAND) values(?)`, article1, (err, res) => {
    if (err) {
      console.log("error: ", err);
      result(err, null);
      return;}

    console.log("created tutorial: ", { idARTICLE: res.insertId, ...article });
    result(null, { idARTICLE: res.insertId, ...article1 });
  });
};

Tutorial.findById = (brandid,result) => {
  sql.query(`Select * from article where idBRAND=${brandid}`, (err, res) => {
    if (err) {
      console.log("error: ", err);
      result(err, null);
      return;
    }
    if (res.length) {
      console.log("found tutorial: ", res);
      result(null, res);
      return res;
    }
console.log("1st");
    // not found Tutorial with the id
    return({ kind: "not_found" }, null);
  });
};
Tutorial.findByBrandId = (title,result) => {

  var stringQuery = `Select * from article  WHERE
  idBRAND= '${title}'`;
  sql.query(stringQuery, (err, res) => {
    if (err) {
      console.log("error: ", err);
      result(err, null);
      return;
    }
    if (res.length) {
      console.log("found tutorial: ", res);
      result(null, res);
      return res;
    }
    else{
    return({ kind: "not_found" }, null);}
  });
};Tutorial.findByBrandIdAndSize = (brandId,article,size,colour,result) => {

  var stringQuery = `SELECT b.BRAND, a.ARTICLE , s.SIZE, g.GENDER, q.QUANTITY, m.MRP , c.COLOUR
  FROM brand b join article a ON
  b.idBRAND=a.idBRAND JOIN size s ON
  a.idARTICLE=s.idARTICLE join gender g ON
  s.idGENDER= g.idGENDER JOIN colour c ON
  s.idCOLOUR=c.idCOLOUR JOIN quantity q ON
  s.idSIZE= q.idSIZE JOIN mrp m ON
  q.idQUANTITY= m.idQUANTITY WHERE `
  if(brandId!='null')
  {
    stringQuery+=`b.idBRAND= '${brandId}'`;
  }
  if(article!='null')
  {
    stringQuery+=` and a.idARTICLE = '${article}'`;
  }
  if(colour!='null')
  {
    stringQuery+=`and c.idCOLOUR = '${colour}'`;
  }
  if(size!='null')
  {
    stringQuery+=` and s.idSIZE = '${size}'`;
  }
  
  sql.query(stringQuery, (err, res) => {
    if (err) {
      console.log("error: ", err);
      result(err, null);
      return;
    }
    if (res.length) {
      console.log("found tutorial: ", res);
      result(null, res);
      return res;
    }
    else{
      console.log('No Data')
      return {"data":"no Data Found"};
    }
    return({ kind: "not_found" }, null);
  });
};
Tutorial.findByBrandIdAndArticle = (brandId,article,result) => {

  var stringQuery = `SELECT b.BRAND, a.ARTICLE , s.SIZE, q.QUANTITY, m.MRP , c.COLOUR
  FROM brand b join article a ON
  b.idBRAND=a.idBRAND JOIN size s ON
  a.idARTICLE=s.idARTICLE  JOIN colour c ON
  s.idCOLOUR=c.idCOLOUR JOIN quantity q ON
  s.idSIZE= q.idSIZE JOIN mrp m ON
  q.idQUANTITY= m.idQUANTITY WHERE `
  if(brandId!='null')
  {
    stringQuery+=`b.idBRAND= '${brandId}'`;
  }
  if(article!='null')
  {
    stringQuery+=` and a.idARTICLE = '${article}'`;
  }
  
  sql.query(stringQuery, (err, res) => {
    if (err) {
      console.log("error: ", err);
      result(err, null);
      return;
    }
    if (res.length) {
      console.log("found tutorial: ", res);
      result(null, res);
      return res;
    }
    else{
      console.log('No Data')
      result(null, {"data":"no Data Found"});
      return {"data":"no Data Found"};
    }
    return({ kind: "not_found" }, null);
  });
};Tutorial.findByBrandIdAndArticle1 = (brandId,article,result) => {
  var stringQuery = `SELECT * from article WHERE `
  if(brandId!='null')
  {
    stringQuery+=`idBRAND= '${brandId}'`;
  }
  if(article!='null')
  {
    stringQuery+=` and ARTICLE = '${article}'`;
  }
  sql.query(stringQuery, (err, res) => {
    if (err) {
      console.log("error: ", err);
      result(null,err);
      return;
    }if(res.length){
    result(null,res[0]);}
    else{console.log("No brand found for the title: ");
      result({ kind: "not_found" }, null); }
  });
};
Tutorial.getAll = (title,result) => {
  let query = "SELECT * FROM article";
  if (title) {
    query += ` WHERE idARTICLE LIKE '%${title}%'`;
  }
  sql.query(query, (err, res) => {
    if (err) {
      console.log("error: ", err);
      result(null,err);
      return;
    }console.log("tutorials: ", res);
    result(null,res);
  });
};



Tutorial.getAllPublished = article => {
  sql.query("SELECT * FROM article WHERE published=true", (err, res) => {
    if (err) {
      console.log("error: ", err);
      result(null, err);
      return;
    }
    console.log("tutorials: ", res);
    result(null, res);
  });
};

Tutorial.updateById = (idARTICLE, ARTICLE, result) => {
  sql.query(
    "UPDATE article SET ARTICLE = ? WHERE idARTICLE = ?",
    [ARTICLE, idARTICLE],
    (err, res) => {
      if (err) {
        console.log("error: ", err);
        result(null, err);
        return;
      }
      if (res.affectedRows == 0) {
        // not found Tutorial with the id
        result({ kind: "not_found" }, null);
        return;
      } console.log("updated tutorial: ", { ARTICLE: ARTICLE, ...idARTICLE });
      result(null, { ARTICLE: ARTICLE, ...idARTICLE });
    }
  );
};

Tutorial.remove = (idARTICLE, result) => {
  sql.query("DELETE FROM article WHERE idARTICLE = ?", idARTICLE, (err, res) => {
    if (err) {
      console.log("error: ", err);
      result(null, err);
      return;
    }

    if (res.affectedRows == 0) {
      // not found Tutorial with the id
      result({ kind: "not_found" }, null);
      return;
    }

    console.log("deleted tutorial with id: ", idARTICLE);
    result(null, res);
  });
};

Tutorial.removeAll = result => {
  sql.query("DELETE FROM article", (err, res) => {
    if (err) {
      console.log("error: ", err);
      result(null, err);
      return;
    }

    console.log(`deleted ${res.affectedRows} article`);
    result(null, res);
  });
};

module.exports = Tutorial;
