
const sql = require("./db.js");

// constructor
const Tutorial = function(mrp) {
  this.idMRP = mrp.idMRP;
  this.MRP = mrp.MRP;
  this.idARTICLE = mrp.idARTICLE ;
};
const Tutorial1 = function(article) {
    this.idARTICLE = article.idARTICLE;
}
Tutorial.create = (newTutorial, result) => {
  sql.query("INSERT INTO mrp SET ?", newTutorial, (err, res) => {
    if (err) {
      console.log("error: ", err);
      result(err, null);
      return;}

    console.log("created tutorial: ", { idSIZE: res.insertId, ...newTutorial });
    result(null, { idMRP: res.insertId, ...newTutorial });
  });
};
Tutorial.findById1 = (title,mrp,result) => {
  sql.query(`SELECT * FROM mrp WHERE idSIZE LIKE '${title}' and MRP LIKE '${mrp}'`, (err, res) => {
    if (err) {
      console.log("error: ", err);
      result(err, null);
      return;
    }
    if (res.length) {
      console.log("found tutorial: ", res[0]);
      result(null, res[0]);
      return res;
    }else{console.log("No MRP found for the title: ", title);
      result({ kind: "not_found" }, null); }
  });
};
Tutorial.findById = (title,result) => {
  sql.query(`SELECT * FROM mrp WHERE idSIZE LIKE '${title}'`, (err, res) => {
    if (err) {
      console.log("error: ", err);
      result(err, null);
      return;
    }
    if (res.length) {
      console.log("found tutorial: ", res);
      result(null, res);
      return res;
    }else{
      console.log("No brand found for the title: ");
    // not found Tutorial with the id
    return({ kind: "not_found" }, null);}
  });
};

Tutorial.getAll = (title,result) => {
  let query = "SELECT * FROM mrp";
  if (title) {
    query += ` WHERE idMRP LIKE '%${title}%'`;
  }
  sql.query(query, (err, res) => {
    if (err) {
      console.log("error: ", err);
      result(null,err);
      return;
    }console.log("tutorials: ", res);
    result(null,res);
  });
};



Tutorial.getAllPublished = article => {
  sql.query("SELECT * FROM mrp WHERE published=true", (err, res) => {
    if (err) {
      console.log("error: ", err);
      result(null, err);
      return;
    }
    console.log("tutorials: ", res);
    result(null, res);
  });
};

Tutorial.updateById = (MRP, idMRP, result) => {
  sql.query(
    "UPDATE mrp SET MRP = ? WHERE idMRP = ?",
    [MRP,idMRP],
    (err, res) => {
      if (err) {
        console.log("error: ", err);
        result(null, err);
        return;
      }
      if (res.affectedRows == 0) {
        // not found Tutorial with the id
        result({ kind: "not_found" }, null);
        return;
      } console.log("updated tutorial: ", { SIZE: size.SIZE, ...size.idARTICLE });
      result(null, { MRP: mrp.MRP, ...idARTICLE });
    }
  );
};

Tutorial.remove = (idMRP, result) => {
  sql.query("DELETE FROM mrp WHERE idMRP = ?", idSIZE, (err, res) => {
    if (err) {
      console.log("error: ", err);
      result(null, err);
      return;
    }

    if (res.affectedRows == 0) {
      // not found Tutorial with the id
      result({ kind: "not_found" }, null);
      return;
    }

    console.log("deleted tutorial with id: ", idSIZE);
    result(null, res);
  });
};

Tutorial.removeAll = result => {
  sql.query("DELETE FROM mrp", (err, res) => {
    if (err) {
      console.log("error: ", err);
      result(null, err);
      return;
    }

    console.log(`deleted ${res.affectedRows} size`);
    result(null, res);
  });
};

module.exports = Tutorial;
