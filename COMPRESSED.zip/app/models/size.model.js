
const sql = require("./db.js");

// constructor
const Tutorial = function(size) {
  this.idSIZE = size.idSIZE;
  this.SIZE = size.SIZE;
  this.idARTICLE = size.idARTICLE ;
};
const Tutorial1 = function(article) {
    this.idARTICLE = article.idARTICLE;
}
Tutorial.create = (newTutorial, result) => {
  sql.query("INSERT INTO size SET ?", newTutorial, (err, res) => {
    if (err) {
      console.log("error: ", err);
      result(err, null);
      return;}

    console.log("created tutorial: ", { idSIZE: res.insertId, ...newTutorial });
    result(null, { idSIZE: res.insertId, ...newTutorial });
  });
};

Tutorial.findById = (title,result) => {
  sql.query(`SELECT * FROM size WHERE idARTICLE=?`,[title], (err, res) => {
    if (err) {
      console.log("error: ", err);
      result(err, null);
      return;
    }
    if (res.length) {
      console.log("found tutorial: ", res);
      result(null, res);
      return res;
    }
console.log("1st");
    // not found Tutorial with the id
    return({ kind: "not_found" }, null);
  });
};Tutorial.findByIdandsize = (title,id,result) => {
  console.log(id);
  console.log(title);
  sql.query(`select * from size s join article a on s.idARTICLE=a.idARTICLE join colour c on s.idCOLOUR = c.idCOLOUR  where a.idARTICLE=? and c.idCOLOUR =?;`,[title, id], (err, res) => {
    if (err) {
      console.log("error: ", err);
      result(err, null);
      return;
    }
    if (res.length) {
      console.log("found tutorial: ", res);
      result(null, res);
      return res;
    }
    // not found Tutorial with the id
    return({ kind: "not_found" }, null);
  });
};
Tutorial.findByIdandsize1 = (idARTICLE,idCOLOUR,SIZE,result) => {
  sql.query(`select * from size  where idARTICLE=? and idCOLOUR =? and SIZE=?;`,[idARTICLE, idCOLOUR, SIZE], (err, res) => {
    if (err) {
      console.log("error: ", err);
      result(err, null);
      return;
    }
    if (res.length) {
      console.log("found tutorial: ", res[0]);
      result(null, res[0]);
      return res;
    }else{console.log("No SIZE found for the title: ", idARTICLE);
      result({ kind: "not_found" }, null); }
  });
};

Tutorial.getAll = (title,result) => {
  let query = "SELECT * FROM size";
  if (title) {
    query += ` WHERE idSIZE LIKE '%${title}%'`;
  }
  sql.query(query, (err, res) => {
    if (err) {
      console.log("error: ", err);
      result(null,err);
      return;
    }console.log("tutorials: ", res);
    result(null,res);
  });
};



Tutorial.getAllPublished = article => {
  sql.query("SELECT * FROM size WHERE published=true", (err, res) => {
    if (err) {
      console.log("error: ", err);
      result(null, err);
      return;
    }
    console.log("tutorials: ", res);
    result(null, res);
  });
};

Tutorial.updateById = (SIZE, idSIZE, result) => {
  sql.query(
    "UPDATE size SET SIZE = ? WHERE idSIZE = ?",
    [size.SIZE, size.idSIZE],
    (err, res) => {
      if (err) {
        console.log("error: ", err);
        result(null, err);
        return;
      }
      if (res.affectedRows == 0) {
        // not found Tutorial with the id
        result({ kind: "not_found" }, null);
        return;
      } console.log("updated tutorial: ", { SIZE: size.SIZE, ...size.idARTICLE });
      result(null, { SIZE: size.SIZE, ...idARTICLE });
    }
  );
};

Tutorial.remove = (idSIZE, result) => {
  sql.query("DELETE FROM size WHERE idSIZE = ?", idSIZE, (err, res) => {
    if (err) {
      console.log("error: ", err);
      result(null, err);
      return;
    }

    if (res.affectedRows == 0) {
      // not found Tutorial with the id
      result({ kind: "not_found" }, null);
      return;
    }

    console.log("deleted tutorial with id: ", idSIZE);
    result(null, res);
  });
};

Tutorial.removeAll = result => {
  sql.query("DELETE FROM size", (err, res) => {
    if (err) {
      console.log("error: ", err);
      result(null, err);
      return;
    }

    console.log(`deleted ${res.affectedRows} size`);
    result(null, res);
  });
};

module.exports = Tutorial;
