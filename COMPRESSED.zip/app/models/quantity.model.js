
const sql = require("./db.js");

// constructor
const Tutorial = function(quantity) {
  this.idQUANTITY = quantity.idQUANTITY;
  this.QUANTITY = quantity.QUANTITY;
  this.idSIZE = quantity.idSIZE ;
};
const Tutorial1 = function(size) {
    this.idSIZE = size.idSIZE;
}
Tutorial.create = (newTutorial, result) => {
  sql.query("INSERT INTO quantity SET ?", newTutorial, (err, res) => {
    if (err) {
      console.log("error: ", err);
      result(err, null);
      return;}

    console.log("created tutorial: ", { idSIZE: res.insertId, ...newTutorial });
    result(null, { idQUANTITY: res.insertId, ...newTutorial });
  });
};

Tutorial.findById = (title,id,id1,result) => {
  sql.query(`Select * from quantity q join  size s  on q.idSIZE = s.idSIZE join colour c on s.idCOLOUR =c.idCOLOUR join article a on s.idARTICLE = a.idARTICLE where a.idARTICLE = ? and s.idSIZE=? and c.idCOLOUR=?`,[title,id,id1], (err, res) => {
    if (err) {
      console.log("error: ", err);
      result(err, null);
      return;
    }
    if (res.length) {
      console.log("found tutorial: ", res[0]);
      result(null, res[0]);
      return res;
    }
    // not found Tutorial with the id
    return({ kind: "not_found" }, null);
  });
};
Tutorial.findById1 = (title, result) => {
  sql.query(`SELECT * FROM quantity WHERE idMRP = ?`, [title], (err, res) => {
    if (err) {
      console.log("Error: ", err);
      result(err, null); // Call result with error
      return;
    }

    if (res.length) {
      console.log("Found quantity: ", res);
      result(null, res); // Call result with found data
    } else {
      console.log("No quantity found for idMRP: ", title);
      result({ kind: "not_found" }, null); // Call result with not found message
    }
  });
};
Tutorial.ins = (title,result) => {
  sql.query(`INSERT INTO quantity (idSIZE, QUANTITY) VALUES (?, 1) `,[title], (err, res) => {
    if (err) {
      console.log("error: ", err);
      result(err, null);
      return;}

    console.log("created tutorial: ", { idSIZE: res.insertId, ...title });
    result(null, { idQUANTITY: res.insertId });
  });
};

Tutorial.getAll = (title,result) => {
  let query = "SELECT * FROM quantity";
  if (title) {
    query += ` WHERE idQUANTITY LIKE '%${title}%'`;
  }
  sql.query(query, (err, res) => {
    if (err) {
      console.log("error: ", err);
      result(null,err);
      return;
    }console.log("tutorials: ", res);
    result(null,res);
  });
};



Tutorial.getAllPublished = quantity => {
  sql.query("SELECT * FROM quantity q WHERE ", (err, res) => {
    if (err) {
      console.log("error: ", err);
      result(null, err);
      return;
    }
    console.log("tutorials: ", res);
    result(null, res);
  });
};Tutorial.updateByAdd = (idQUANTITY,result) => {
  sql.query(
    `UPDATE quantity SET QUANTITY = QUANTITY + 1 WHERE idQUANTITY = ? `,
    [idQUANTITY],
    (err, res) => {
      if (err) {
        console.log("error: ", err);
        result(null, err);
        return;
      }
      if (res.affectedRows == 0) {
        // not found Tutorial with the id
        result({ kind: "not_found" }, null);
        return;
      } console.log("updated tutorial: ");
    }
  );
  result(null,idQUANTITY);

};
Tutorial.updateByDelete = (idQUANTITY,result) => {
  sql.query(
    `UPDATE quantity SET QUANTITY = QUANTITY - 1 WHERE idQUANTITY = ? AND QUANTITY>0 `,
    [idQUANTITY],
    (err, res) => {
      if (err) {
        console.log("error: ", err);
        result(null, err);
        return;
      }
      if (res.affectedRows == 0) {
        // not found Tutorial with the id
        result({ kind: "not_found" }, null);
        return;
      } console.log("updated tutorial: ");
    }
  );
 /* sql.query(
    `insert into salesdate(idQuantity,salesdate) values(?,curdate())`,
    [idQUANTITY],
    (err, res) => {
      if (err) {
        console.log("error: ", err);
        result(null, err);
        return;
      }
      if (res.affectedRows == 0) {
        // not found Tutorial with the id
        result({ kind: "not_found" }, null);
        return;
      } console.log("updated tutorial: ");
    }
  );sql.query(``)*/
  result(null,idQUANTITY);

};

Tutorial.updateById = (idQUANTITY,id1,result) => {
  sql.query(
    `UPDATE quantity SET QUANTITY = ? WHERE idQUANTITY = ?`,
    [id1,idQUANTITY],
    (err, res) => {
      if (err) {
        console.log("error: ", err);
        result(null, err);
        return;
      }
      if (res.affectedRows == 0) {
        // not found Tutorial with the id
        result({ kind: "not_found" }, null);
        return;
      } console.log("updated tutorial: ");
      result(null,idQUANTITY,id1);
    }
  );
};
Tutorial.remove = (idQUANTITY, result) => {
  sql.query("DELETE FROM quantity WHERE idQUANTITY = ?", idQUANTITY, (err, res) => {
    if (err) {
      console.log("error: ", err);
      result(null, err);
      return;
    }

    if (res.affectedRows == 0) {
      // not found Tutorial with the id
      result({ kind: "not_found" }, null);
      return;
    }

    console.log("deleted tutorial with id: ", idSIZE);
    result(null, res);
  });
};

Tutorial.removeAll = result => {
  sql.query("DELETE FROM quantity", (err, res) => {
    if (err) {
      console.log("error: ", err);
      result(null, err);
      return;
    }

    console.log(`deleted ${res.affectedRows} size`);
    result(null, res);
  });
};

module.exports = Tutorial;
