
const { col } = require("sequelize");
const sql = require("./db.js");

// constructor
const Tutorial = function(colour) {
  this.idCOLOUR = colour.idCOLOUR;
  this.COLOUR = colour.COLOUR;
  this.idARTICLE = colour.idARTICLE ;
};
const Tutorial1 = function(article) {
    this.idARTICLE = article.idARTICLE;
}
Tutorial.create = (newTutorial, result) => {
  sql.query("INSERT INTO colour SET ?", newTutorial, (err, res) => {
    if (err) {
      console.log("error: ", err);
      result(err, null);
      return;}

    console.log("created tutorial: ", { idSIZE: res.insertId, ...newTutorial });
    result(null, { idCOLOUR: res.insertId, ...newTutorial });
  });
};
Tutorial.findByColour = (title,result) => {
  sql.query(`Select * from colour where COLOUR = ?`,[title], (err, res) => {
    if (err) {
      console.log("error: ", err);
      result(err, null);
      return;
    }
    if (res.length) {
      console.log("found tutorial: ", res[0]);
      result(null, res[0]);
      return res;
    }else{console.log("No brand found for the title: ", title);
      result({ kind: "not_found" }, null); }
  });
};
Tutorial.findById = (title,result) => {
  console.log(title);
  sql.query(`Select * from size s join  colour c  on s.idCOLOUR = c.idCOLOUR where idSIZE = ?`,[title], (err, res) => {
    if (err) {
      console.log("error: ", err);
      result(err, null);
      return;
    }
    if (res.length) {
      console.log("found tutorial: ", res);
      result(null, res);
      return res;
    }
    // not found Tutorial with the id
    return({ kind: "not_found" }, null);
  });
};

Tutorial.getAll = (title,result) => {
  let query = "SELECT * FROM colour";
  if (title) {
    query += ` WHERE idCOLOUR LIKE '%${title}%'`;
  }
  sql.query(query, (err, res) => {
    if (err) {
      console.log("error: ", err);
      result(null,err);
      return;
    }console.log("tutorials: ", res);
    result(null,res);
  });
};



Tutorial.getAllPublished = colour => {
  sql.query("SELECT * FROM colour WHERE published=true", (err, res) => {
    if (err) {
      console.log("error: ", err);
      result(null, err);
      return;
    }
    console.log("tutorials: ", res);
    result(null, res);
  });
};

Tutorial.updateById = (COLOUR, idCOLOUR, result) => {
  sql.query(
    "UPDATE colour SET COLOUR = ? WHERE idCOLOUR = ?",
    [colour.COLOUR, colour.idCOLOUR],
    (err, res) => {
      if (err) {
        console.log("error: ", err);
        result(null, err);
        return;
      }
      if (res.affectedRows == 0) {
        // not found Tutorial with the id
        result({ kind: "not_found" }, null);
        return;
      } console.log("updated tutorial: ", { SIZE: size.SIZE, ...size.idARTICLE });
      result(null, { COLOUR: colour.COLOUR, ...idARTICLE });
    }
  );
};

Tutorial.remove = (idCOLOUR, result) => {
  sql.query("DELETE FROM colour WHERE idCOLOUR = ?", idCOLOUR, (err, res) => {
    if (err) {
      console.log("error: ", err);
      result(null, err);
      return;
    }

    if (res.affectedRows == 0) {
      // not found Tutorial with the id
      result({ kind: "not_found" }, null);
      return;
    }

    console.log("deleted tutorial with id: ", idSIZE);
    result(null, res);
  });
};

Tutorial.removeAll = result => {
  sql.query("DELETE FROM colour", (err, res) => {
    if (err) {
      console.log("error: ", err);
      result(null, err);
      return;
    }

    console.log(`deleted ${res.affectedRows} size`);
    result(null, res);
  });
};

module.exports = Tutorial;
