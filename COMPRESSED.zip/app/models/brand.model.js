
const sql = require("./db.js");

// constructor
const Tutorial = function(brand) {
  this.idBRAND = brand.idBRAND;
  this.BRAND = brand.BRAND;
};

Tutorial.create = (newTutorial, result) => {
  sql.query("INSERT INTO brand SET ?", newTutorial, (err, res) => {
    if (err) {
      console.log("error: ", err);
      result(err, null);
      return;
    }

    console.log("created tutorial: ", { idBRAND: res.insertId, ...newTutorial });
    result(null, { idBRAND: res.insertId, ...newTutorial });
  });
};

Tutorial.findById = (title,result) => {
  sql.query(`SELECT * FROM brand WHERE idBRAND LIKE '${title}'`, (err, res) => {
    if (err) {
      console.log("error: ", err);
      result(err, null);
      return;
    }
    if (res.length) {
      console.log("found tutorial: ", res[0]);
      result(null, res[0]);
      return res;
    }
    // not found Tutorial with the id
    return({ kind: "not_found" }, null);
  });
};

Tutorial.getAll = (title,result) => {
  let query = "SELECT * FROM brand";
  if (title) {
    query += ` WHERE idBRAND LIKE '%${title}%'`;
  }
  sql.query(query, (err, res) => {
    if (err) {
      console.log("error: ", err);
      result(null,err);
      return;
    }console.log("tutorials: ", res);
    result(null,res);
  });
};
Tutorial.findByName = (title,result) => {console.log("5th");
  sql.query(`SELECT * FROM brand WHERE BRAND LIKE '${title}'`, (err, res) => {
    if (err) {
      console.log("error: ", err);
      result(err, null);
      return;
    }
    if (res.length) {
      console.log("found tutorial: ", res[0]);
      result(null, res[0]);
      return res;
    }else{console.log("No brand found for the title: ", title);
      result({ kind: "not_found" }, null); }
    // not found Tutorial with the id
  });
};



Tutorial.getAllPublished = brand => {
  sql.query("SELECT * FROM brand WHERE published=true", (err, res) => {
    if (err) {
      console.log("error: ", err);
      result(null, err);
      return;
    }
    console.log("tutorials: ", res);
    result(null, res);
  });
};

Tutorial.updateById = (idBRAND, BRAND, result) => {
  sql.query(
    "UPDATE brand SET BRAND = ? WHERE idBRAND = ?",
    [BRAND,idBRAND],
    (err, res) => {
      if (err) {
        console.log("error: ", err);
        result(null, err);
        return;
      }
      if (res.affectedRows == 0) {
        // not found Tutorial with the id
        result({ kind: "not_found" }, null);
        return;
      } console.log("updated tutorial: ", { BRAND:BRAND, ...idBRAND });
      result(null, { BRAND: BRAND, ...idBRAND });
    }
  );
};

Tutorial.remove = (idBRAND, result) => {
  sql.query("DELETE FROM brand WHERE idBRAND = ?", idBRAND, (err, res) => {
    if (err) {
      console.log("error: ", err);
      result(null, err);
      return;
    }

    if (res.affectedRows == 0) {
      // not found Tutorial with the id
      result({ kind: "not_found" }, null);
      return;
    }

    console.log("deleted tutorial with id: ", idBRAND);
    result(null, res);
  });
};

Tutorial.removeAll = result => {
  sql.query("DELETE FROM brand", (err, res) => {
    if (err) {
      console.log("error: ", err);
      result(null, err);
      return;
    }

    console.log(`deleted ${res.affectedRows} brand`);
    result(null, res);
  });
};

module.exports = Tutorial;
