import { BrowserRouter, Routes, Route } from "react-router-dom";
import React from "react";
import UserList from "./components/UserList";
import AddUser from "./components/AddUser";
import AddBrand from "./components/AddBrand";
import Dropdown from "./components/Dropdown.js";
import DeleteUser from "./components/DeleteUser.js";
import { useTable } from "react-table";
import "../node_modules/bootstrap/dist/css/bootstrap.min.css";
import AddArticle from "./components/AddArticle";
import AddColour from "./components/AddColour";
import PrintPage from "./components/PrintComponent.js";
import BarcodeComponent from "./components/BarcodePrintComponent.js";
import TopBar from "./components/TopBar";
function Table({ columns, data }) {
  // Use the state and functions returned from useTable to build your UI
  const {
    getTableProps,
    getTableBodyProps,
    headerGroups,
    rows,
    prepareRow,
  } = useTable({
    columns,
    data,
  })

  // Render the UI for your table
  return (
    <table {...getTableProps()}>
      <thead>
        {headerGroups.map(headerGroup => (
          <tr {...headerGroup.getHeaderGroupProps()}>
            {headerGroup.headers.map(column => (
              <th {...column.getHeaderProps()}>{column.render('Header')}</th>
            ))}
          </tr>
        ))}
      </thead>
      <tbody {...getTableBodyProps()}>
        {rows.map((row, i) => {
          prepareRow(row)
          return (
            <tr {...row.getRowProps()}>
              {row.cells.map(cell => {
                return <td {...cell.getCellProps()}>{cell.render('Cell')}</td>
              })}
            </tr>
          )
        })}
      </tbody>
    </table>
  )
}

function App() {
  


  return (
    
    <BrowserRouter>
 <div>
        {/* Top Bar */}
        <TopBar />
        <div className="flex justify-center mt-8">
        <div className="w-4/5 bg-white border border-gray-300 shadow-lg rounded-lg p-8">
    <Routes>
      <Route path="/" element={<DeleteUser/>}/>
      <Route path="add" element={<AddUser/>}/>
      <Route path="add/addbrand" element={<AddBrand/>}/>
      <Route path="add/addcolour" element={<AddColour/>}/>
      <Route path="add/addarticle" element={<AddArticle/>}/>
      <Route path="delete" element={<DeleteUser/>}/>
      <Route path="stock" element={<Dropdown/>}/>
      <Route path="print" element={<PrintPage/>}/>
      <Route path="barcode" element={<BarcodeComponent/>}/>
    </Routes>
    </div>
    </div>
  </div>
    
     </BrowserRouter>
  );
  }
export default App;