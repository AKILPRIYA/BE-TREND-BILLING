import React, {useState, useEffect} from "react";
import Select from "react-dropdown-select";
import axios from "axios"; 


const Dropdown = ({ placeHolder }) => {
    
    const[users, setUser] = useState(['']);
    const[sizes, setSize] = useState(['']);
    const[article, setArticle] = useState(['']);
    const[colour,setColour] = useState([]);
    const[filter,setFilter]=useState('');
    const[selectedColour,setSelectedColour] = useState(null);
    const[selectedBrand,setSelectedBrand] = useState(null);
    const[selectedSize,setSelectedSize] = useState(null);
    const[selectedArticle,setSelectedArticle] = useState(null);
    const[data,setData] = useState([]);

    useEffect(()=>{getUsers();
      getArticle();
      },[]);
      const saveUser = async (e) =>{
        e.preventDefault();
        try{
         var url= "http://localhost:8080/api/article/brand/"+selectedBrand+"/"+selectedArticle;
         const response=await axios.get(url);
         setData(response.data);
        }
        catch(error){
            console.log(error);
        }
    };
        const onBrandClick = async (brand) =>{
          if(brand!==undefined){
          setSelectedBrand(brand.idBRAND);
          const response1 = await axios.get("http://localhost:8080/api/article/"+brand.idBRAND);
          setArticle(response1.data);
          return response1;   
          }
        };
        const onArticleClick = async (article) =>{
          if(article!==undefined){
          setSelectedArticle(article.idARTICLE)
          const response1 = await axios.get("http://localhost:8080/api/size/"+article.idARTICLE);
          return response1;   
          }
        };
    const getUsers = async () => {
        const response = await axios.get("http://localhost:8080/api/brand");
        setUser(response.data);
        return response.data;
        
    };
  const getArticle = async () => {
    const response = await axios.get("http://localhost:8080/api/article");
    setArticle(response.data);
    return response.data; 
}; 
 return (
  <form onSubmit={saveUser}>
    <div>
   <Select searchable={true} sortBy = "BRAND" searchBy="BRAND" options = {users} labelField="BRAND" valueField="idBRAND" onChange={(values)=>onBrandClick(values[0])} />
   <Select searchable={true} searchBy="ARTICLE" options = {article} labelField="ARTICLE" valueField="idARTICLE" onChange={(values)=>onArticleClick(values[0])} />
     <div className="field">
     <button type="submit" className="button is-success">
         Search
     </button></div></div>
     <div>
      <table><thead>
<th>
BRAND
</th>
<th>
Article
</th><th>SIZE</th><th>COLOUR</th><th>QUANTITY</th><th>MRP</th></thead>
<tbody>
{data.map((item,index) => (
  <tr key={index}>
    <td>{item.BRAND}</td>
    <td>{item.ARTICLE}</td>
    <td>{item.SIZE}</td>
    <td>{item.COLOUR}</td>
    <td>{item.QUANTITY}</td>
    <td>{item.MRP}</td>
  </tr>  
))
}</tbody>
      </table>
      </div></form>
     

     );
};
export default Dropdown;