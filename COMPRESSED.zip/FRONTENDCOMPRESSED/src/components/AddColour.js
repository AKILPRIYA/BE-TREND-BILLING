import React,{useState} from 'react';
import axios from "axios";
import { useNavigate} from 'react-router-dom';

const AddColour = () => {
    const [COLOUR , setColour] =useState("");
    const navigate = useNavigate();
    const updateUser = async (e) =>{
        e.preventDefault();
        try{
            await axios.post(`http://localhost:8080/api/colour/post`, {
                COLOUR
            });navigate("/add");   
        }catch(error){
            console.log(error);
        }
    };
  return (
    <div className="columns mt-5 is-centered">
        <div className="column is-half">
            <form onSubmit={updateUser}>
                <div className="field">
                    <label className="label">COLOUR</label>
                    <div className="control">
                        <input type="text" className="input"
                        value={COLOUR}
                        onChange={(e)=> setColour(e.target.value)}
                         placeholder='Colour'/>
                    </div>
                </div>
                <div className="field">
                    <button type="submit" className="button is-success">
                       Update
                    </button>
                </div>
            </form>
        </div>
    </div>
  )
}

export default AddColour