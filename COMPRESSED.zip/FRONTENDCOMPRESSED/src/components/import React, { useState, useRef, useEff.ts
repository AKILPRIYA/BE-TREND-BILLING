import React, { useState, useRef, useEffect } from 'react';
import JsBarcode from 'jsbarcode';
import ReactToPrint from 'react-to-print';
import './PrintPage.css'; 

const BarcodeComponent = React.forwardRef(({ barcodesWithMRP }, ref) => {
  const barcodeRefs = useRef([]);

  useEffect(() => {
    // Generate barcode for each input dynamically
    barcodesWithMRP.forEach((item, index) => {
      JsBarcode(barcodeRefs.current[index], item.barcode, {
        format: "CODE128",
        width: .65,   // Set barcode width to fit within 50mm
        height: 20,   // Set barcode height to fit within 25mm height
        fontSize: 10, // Adjust font size for better readability
        displayValue: false, // Hide the barcode number if needed to save space
        margin: 0,    // Reduce font size of the barcode text
      });
    });
  }, [barcodesWithMRP]);

  return (
    <div style={{ width: '50mm', padding: '5mm', display: 'flex', flexWrap: 'wrap', justifyContent: 'space-between' }}>
      {barcodesWithMRP.map((item, index) => (
        <div 
          key={index} 
          style={{
            width: '48mm',     // 50mm label minus padding/margin
            height: '23mm',    // 25mm height minus padding/margin
            textAlign: 'center',
            display: 'flex',
            flexDirection: 'column',
            justifyContent: 'center',
            alignItems: 'center',
            padding: '1mm'
          }}
        >
          {/* Render the barcode */}
          <svg ref={el => barcodeRefs.current[index] = el}></svg>
          {/* Display MRP below the barcode */}
          <p style={{ fontSize: '8px', margin: '0px', marginTop: '2mm' }}>MRP: ₹{item.mrp}</p>
        </div>
      ))}
    </div>
  );
  
});

const PrintBarcodesPage = () => {
  const [barcodeInput, setBarcodeInput] = useState('');
  const [mrpInput, setMrpInput] = useState('');
  const [barcodesWithMRP, setBarcodesWithMRP] = useState([]);
  const componentRef = useRef();

  const handleAddBarcode = () => {
    if (barcodeInput && mrpInput) {
      setBarcodesWithMRP([...barcodesWithMRP, { barcode: barcodeInput, mrp: mrpInput }]); // Add both barcode and MRP
      setBarcodeInput(''); // Clear barcode input
      setMrpInput('');     // Clear MRP input
    }
  };
 

return (
  <div>
  <input
    type="text"
    placeholder="Enter barcode value"
    value={barcodeInput}
    onChange={(e) => setBarcodeInput(e.target.value)}
  />
  <input
    type="text"
    placeholder="Enter MRP value"
    value={mrpInput}
    onChange={(e) => setMrpInput(e.target.value)}
  />
  <button onClick={handleAddBarcode}>Add Barcode</button>

    {/* Button to trigger printing */}
    <ReactToPrint
      trigger={() => <button>Print Barcodes</button>}
      content={() => componentRef.current}
    />

    {/* The barcode component to be printed */}
    <BarcodeComponent ref={componentRef} barcodesWithMRP={barcodesWithMRP} />
  </div>
);
};export default PrintBarcodesPage;
