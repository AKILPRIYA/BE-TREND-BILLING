import React from 'react';
import { useLocation } from 'react-router-dom';
import ReactToPrint from 'react-to-print';

const PrintComponent = React.forwardRef((props, ref) => (
    <div ref={ref}>
        <h1>Bill Details</h1>
        <ul>
            {props.products.map((product, index) => (
                <li key={index}>
                    {product.brand}: {product.Article}
                </li>
            ))}
        </ul>
    </div>
));

function PrintPage() {
    const location = useLocation();
    const { products } = location.state || { products: [] };
    const componentRef = React.useRef();

    return (
        <div>
            <ReactToPrint
                trigger={() => <button>Print</button>}
                content={() => componentRef.current}
            />
            <PrintComponent ref={componentRef} products={products} />
        </div>
    );
}

export default PrintPage;

