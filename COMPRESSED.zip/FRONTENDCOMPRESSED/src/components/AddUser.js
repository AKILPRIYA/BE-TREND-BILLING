import { BrowserRouter, Routes, Route } from "react-router-dom";
import axios from "axios";
import { useNavigate, useParams } from 'react-router-dom';
import React, {useState, useEffect ,useRef} from "react";
import Select from "react-dropdown-select";
import { Link } from 'react-router-dom';
import './AddUser.css';

const AddUser =  ({ placeHolder }) => {
  const navigate = useNavigate();
  const billRef = useRef();
  const [scannedValue, setScannedValue] = useState('');
const {id} = useParams();
const [message, setMessage] = useState('');
  const [error, setError] = useState('');
const [Brand,setBrand]=useState(null);
const [Article,setarticle]=useState(null);
const [Colour,setcolour]=useState(null);
const [Size,setsize]=useState(null);
const inputRef = useRef(null);
const [rowsData, setRowsData] = useState([]);
    const[users, setUser] = useState("");
    const[sizes, setSize] = useState("");
    const[article, setArticle] = useState("");
    const[purchaseamount, setpurchaseamount] = useState([]);
    const[QUANTITY,setQuantity] = useState([]);
    const[mrp, setMrp] = useState([]);
    const[colour, setColour] = useState([]);
    const [scannedArticle, setscannedArticle] = useState(false);
    const [isDisabled, setIsDisabled] = useState(false);
    const[stockDatas, setStockData] = useState({'COLOUR':'sad'});
    const [ showMenu, setShowMenu] = useState(false);
    const [selectedValue, setSelectedValue] = useState(null);
    const[selectedBrand,setSelectedBrand] = useState(null);
    const[selectedBrandId,setSelectedBrandId] = useState(null);
    const[selectedSize,setSelectedSize] = useState(null);
    const[selectedSizeId,setSelectedSizeId] = useState(null);
    const[idquantity,setidquantity] = useState(null);
    const[idsize,setidsize] = useState(null);
    const[selectedArticle,setSelectedArticle] = useState(null);
    const[selectedArticleId,setSelectedArticleId] = useState(null);
    const[selectedColour,setSelectedColour] = useState(null);
    const[selectedColourId,setSelectedColourId] = useState(null);
    const[selectedQuantity,setSelectedQuantity] = useState(null);
    const [MRP , setMRP] =useState("");
    const [Mrp , setmrp] =useState("");

    useEffect(()=>{getUsers(); const inputField = document.getElementById('scanner-input');
      if (inputField) {
        inputField.focus();
      }
     // getSizes();getArticle();getColour();getQuantity();getMrp();getUserById();
      },[]);
      const saveUser = async (e) =>{
        e.preventDefault();
        try{
          console.log(rowsData);
            await axios.patch("http://localhost:8080/api/quantity/add",{rowsData});
           navigate('/') ;

        }catch(error){
            console.log(error);

        }}
        const onItemClick = async (size) =>{
          if(size!==undefined){
          setSelectedSize(size.idSIZE);
          setsize(size.SIZE);
          const response1 = await axios.get("http://localhost:8080/api/colour/"+size.idSIZE);
          setColour(response1.data);
          }

        };
        const onColourClick = async (colour) =>{
          if(colour!==undefined){
          setSelectedColour(colour.idCOLOUR);
          setcolour(colour.COLOUR);
          const response1 = await axios.get("http://localhost:8080/api/quantity/"+selectedArticle+"/"+selectedSize+"/"+colour.idCOLOUR);
         setidquantity(response1.data.idQUANTITY);
         setidsize(response1.data.idSIZE);
          //return response;
          }

        };
       const onBrandClick = async (brand) =>{
          if(brand!==undefined){
          setSelectedBrand(brand.idBRAND)
          setBrand(brand.BRAND);
          const response1 = await axios.get("http://localhost:8080/api/article/"+brand.idBRAND);
          setArticle(response1.data);
          }
        };
        const onArticleClick = async (article) =>{
          if(article!==undefined){
          setSelectedArticle(article.idARTICLE)
          setarticle(article.ARTICLE);
          const response1 = await axios.get("http://localhost:8080/api/size/"+article.idARTICLE);
          setSize(response1.data)
          }
        };
   const getUsers = async () => {
        const response = await axios.get("http://localhost:8080/api/brand");
        setUser(response.data);
        return response.data;    
    };
    const getSizes = async () => {
      const response = await axios.get("http://localhost:8080/api/size");
      setSize(response.data);
      return response.data; 
  };
  const getColour = async () => {
    const response = await axios.get("http://localhost:8080/api/colour/");
    setColour(response.data);
    return response.data; 
}; 
const getQuantity = async () => {
  const response = await axios.get("http://localhost:8080/api/quantity/");
  setQuantity(response.data); 
  return response.data; 
}; const handleDelete = (id) => {
  const newData = [...rowsData];
  newData.splice(id, 1);
  setRowsData(newData);
};
const getMrp = async () => {
    const response = await axios.get("http://localhost:8080/api/mrp/");
    setMrp(response.data);
    return response.data; 
}; const getArticle = async () => {
    const response = await axios.get("http://localhost:8080/api/article/");
    setArticle(response.data);
          return response.data;
  };  const getUserById = async()=>{
    const response= await axios.get("http://localhost:8080/api/quantity/"+selectedArticle+"/"+selectedSize+"/"+selectedColour);
 return response;
}; const handleInputChange = (e) => {
  setScannedValue(e.target.value);
};const handleKeyPress = (e) => {
  if (e.key === 'Enter' && scannedValue.trim()) {
    processScannedValue(scannedValue.trim());
    
  }
};const checkAndHandleBrand = async (brand, article, size, colour, mrp) => {
  try {
    const response = await axios.get(`http://localhost:8080/api/brand/BRAND/${brand}`);
    if (response.data &&response.status === 200) {
      // If brand exists, select it and fetch related articles
      setSelectedBrandId(response.data.idBRAND);
     handleNewArticle(response.data.idBRAND, article, size, colour,mrp);
    } 
  } catch (error) {
    if (error.response && error.response.status === 404) {
      console.log(brand);
      const newBrandResponse = await axios.post('http://localhost:8080/api/brand/post', {BRAND:brand});
      setSelectedBrandId(newBrandResponse.data.idBRAND);console.log(newBrandResponse.data.idBRAND);
      handleNewArticle(newBrandResponse.data.idBRAND, article, size, colour,mrp);
    }
  }
};
const handleNewArticle = async (BRANDId, article, size, colour,mrp) => {
  try {
    // Fetch or create article
    const articleId = await fetchOrCreateArticle(BRANDId, article);
    
    // Fetch or create colour
    const colourId = await fetchOrCreateColour(colour);

    // Handle size and colour association with the article
    if (articleId && colourId) {
      handleSizeAndColour(articleId, size, colourId,mrp);
    }
  } catch (error) {
    console.error("Error handling new article:", error);
  }
};

const fetchOrCreateArticle = async (BRANDId, article) => {
  try {
    // Try fetching the article for the given brand
    const articleResponse = await axios.get(`http://localhost:8080/api/article/brand1/${BRANDId}/${article}`);
    
    if (articleResponse.status === 200 && articleResponse.data) {
      // Article exists, return the ID
      console.log('Article found:', articleResponse.data);
      setSelectedArticleId(articleResponse.data.idARTICLE);
      setarticle(articleResponse.data.ARTICLE);
      return articleResponse.data.idARTICLE;
    }
  } catch (error) {
    // If article not found, handle 404 and create a new article
    if (error.response && error.response.status === 404) {
      console.log("Article not found, creating new article...");
      try {
        console.log(article);
        const newArticleResponse = await axios.post('http://localhost:8080/api/article/post1', {
          ARTICLE: article,
          idBRAND: BRANDId
        });
        console.log('New article created:', newArticleResponse.data);
        setSelectedArticleId(newArticleResponse.data.idARTICLE);
        return newArticleResponse.data.idARTICLE;
      } catch (createError) {
        console.error("Error creating new article:", createError);
      }
    } else {
      console.error("Error fetching/creating article:", error);
    }
  }
};


const fetchOrCreateColour = async (colour) => {
  try {
    // Try fetching the colour
    const colourResponse = await axios.get(`http://localhost:8080/api/colour/Colour/${colour}`);
    
    if (colourResponse.status === 200 && colourResponse.data) {
      setSelectedColourId(colourResponse.data.idCOLOUR);
      return colourResponse.data.idCOLOUR;
    }
  } catch (error) {
    // If colour not found, create a new one
    if (error.response && error.response.status === 404) {
      console.log("Creating new colour...");
      const newColourResponse = await axios.post('http://localhost:8080/api/colour/post', { COLOUR: colour });
      setSelectedColourId(newColourResponse.data.idCOLOUR);
      return newColourResponse.data.idCOLOUR;
    } else {
      console.error("Error fetching/creating colour:", error);
    }
  }
};

const handleSizeAndColour = async (articleId, size, colour,mrp) => {

  try {
    const sizeResponse = await axios.get(`http://localhost:8080/api/size/${articleId}/${colour}/${size}`);
    if (sizeResponse.data && sizeResponse.status ==200) {
      setSelectedSize(sizeResponse.data.idSIZE);
      handleMrp(sizeResponse.data.idSIZE,mrp);
    } }catch(error) {
      if (error.response && error.response.status === 404) {
      const newSizeResponse = await axios.post('http://localhost:8080/api/size/post1', {idARTICLE:articleId , idCOLOUR:colour, SIZE:size});
      console.log('New Size Response:', newSizeResponse.data);

      if (newSizeResponse.data && newSizeResponse.data.idSIZE) {
        setSelectedSize(newSizeResponse.data.idSIZE);
        handleMrp(newSizeResponse.data.idSIZE, mrp);
      } else {
        console.error('idSIZE not found in response');
      }

    }
    
  } 
};const handleMrp = async (idsize,mrp) =>{
  try{
    const response1 = await axios.get(`http://localhost:8080/api/mrp/${idsize}/${mrp}`);
      if(response1.data && response1.status==200){
    handleQuantity(response1.data.idMRP);}
  }catch(error){
    if(error.response && error.response.status === 404){
      const newMrpResponse = await axios.post(`http://localhost:8080/api/mrp/post1`,{idSIZE:idsize , MRP:mrp});
      console.log('New mrp Response:', newMrpResponse.data);
      handleQuantity(newMrpResponse.data.idMRP);
    }
  }
};const handleQuantity = async(idmrp) =>{
try {
  const response = await axios.get(`http://localhost:8080/api/quantity/${idmrp}`);
 if(response.data && response.status==200){
  setidquantity(response.data[0].idQUANTITY);
  console.log(response.data[0].idQUANTITY);}
} catch (error) {
  if(error.response && error.response.status === 404){
  const newQuantityResponse = await axios.post(`http://localhost:8080/api/quantity/add`,{idMRP:idmrp});
  console.log('New QUANTITY Response:', newQuantityResponse.data);
  setidquantity(newQuantityResponse.data.idQUANTITY);}
}
}
 const [rows, initRow] = useState([]);
const addTableRows = () => {
  let obj = {
    users: selectedBrand,
    article:selectedArticle,
    sizes: selectedSize,
    colour:selectedColour,
    purchaseamount:purchaseamount,
    idquantity:idquantity,
    brand:Brand,
    Article:Article,
    Colour:Colour,
    Size:Size,
    mrp:Mrp
   
}; setIsDisabled(true);
  setRowsData([...rowsData,obj])
  setidquantity(null);
  setSelectedBrand(null);setpurchaseamount('');setScannedValue('');
  setSelectedArticle("");
  setSelectedSize("");
  setSelectedColour(null);
  setSelectedQuantity(null);};
   const processScannedValue = (value) =>{
    const [scannedBrand, scannedArticle, scannedSize, scannedColour, scannedMrp] = value.split('-').map(val => val.trim());
  setSelectedBrand(scannedBrand);
  setSelectedArticle(scannedArticle);
  setSelectedSize(scannedSize);
  setSelectedColour(scannedColour);
setMRP(scannedMrp);setBrand(scannedBrand);setarticle(scannedArticle);setcolour(scannedColour);setsize(scannedSize);setmrp(scannedMrp);
  checkAndHandleBrand(scannedBrand, scannedArticle, scannedSize, scannedColour,scannedMrp);

   }
  
   useEffect(() => {
    if (scannedArticle) {
      addTableRows(); setSelectedArticle(false);
    }
  }, [idsize])

 return (
  <> <div> <input
  ref={inputRef}
  type="text"
  value={scannedValue}
  onChange={handleInputChange}
  onKeyPress={handleKeyPress}
  placeholder="Scan values separated by commas"
  autoFocus
/>
  {error && <div style={{ color: 'red' }}>{error}</div>}</div>
  <td><div className="field">
                    <div className="control">
                        <input type="number" className="input"
                        value={purchaseamount}
                        onChange={(e)=> setpurchaseamount(e.target.value)}
                         placeholder='PURCHASE AMOUNT'/>
                    </div>
                </div></td><td><button className="btn btn-outline-success"  onClick={addTableRows} disabled = {idquantity==null} >+</button></td>

    {
    <table>
    <thead>
      <tr>
        <th>BRAND</th>
        <th>ARTICLE</th>
        <th>SIZE</th>
        <th>COLOUR</th>
        <th>MRP</th>
      </tr>
    </thead>
    <tbody>
      {rowsData.map((data, index) => (
        <tr key={index}> 
          
          <td>{data.brand}</td>
          <td>{data.Article}</td>
          <td>{data.Size}</td>
          <td>{data.Colour}</td>
          <td>{data.mrp}</td>
          <td><button onClick={() => handleDelete(data.index)}>-</button></td>
        </tr>))}
    </tbody>
  </table>}
    <div className="field">
                    <button type="submit" className="button is-success" onClick={saveUser} >
                        Save
                    </button></div> </>);
};
export default AddUser;