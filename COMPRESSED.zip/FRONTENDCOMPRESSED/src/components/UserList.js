import React, {useState, useEffect} from 'react';
import { Link } from 'react-router-dom';

const UserList = () => {

  return (
    <div className="h-screen w-1/5 bg-gray-800 text-white flex flex-col items-start p-5">
    <h2 className="text-2xl font-bold mb-6">Menu</h2>
    <button className="w-full mb-4">
      <Link to={'add'} className="w-full block bg-green-500 text-white font-bold py-2 px-4 rounded hover:bg-green-700">
        Add New
      </Link>
    </button>
    <button className="w-full mb-4">
      <Link to={'stock'} className="w-full block bg-green-500 text-white font-bold py-2 px-4 rounded hover:bg-green-700">
        Display Stock
      </Link>
    </button>
    <button className="w-full mb-4">
      <Link to={'delete'} className="w-full block bg-green-500 text-white font-bold py-2 px-4 rounded hover:bg-green-700">
        Sales
      </Link>
    </button>
    <button className="w-full">
      <Link to={'barcode'} className="w-full block bg-green-500 text-white font-bold py-2 px-4 rounded hover:bg-green-700">
        Barcode
      </Link>
    </button>
  </div>)
/*  const getUsers1 = async () => {
    const response1 = await axios.get("http://localhost:8080/api/article");
    setUser(response1.data);
};
const deleteUser1 = async (id)=>{
    try {
        await axios.delete(`http://localhost:8000/api/article/${id}`);
        getUsers1();
        
    } catch (error) {
        console.log(error);
        
    }
}

return (
<div className="columns mt-5 is-centered">
    <div className="column is-half">
        <Link to={'add'} className="button is-success">
            Add New</Link>

       <table className="table is-striped is-fullwidth">
        <thead>
            <tr>
                <th>ID</th>
                <th>ARTICLE</th>
                <th>IDBRAND</th>
                <th>ACTIONS</th>
            </tr>
        </thead>
        <tbody>
            {users.map((article, index)=>(
                <tr key={article.idARTICLE}>
                <td>{article.idARTICLE}</td>
                <td>{article.ARTICLE}</td>
                <td>{article.idBRAND}</td>
                <td>
                    <Link to={`edit/${article.idARTICLE}`} className="button is-small is-info">Edit</Link>
                    <button onClick={()=> deleteUser1(article.idARTICLE)} className="button is-small is-danger">Delete</button>
                </td>
            </tr>

            )
            )}
        </tbody>
       </table>
    </div>
</div>
)*/
}

export default UserList;