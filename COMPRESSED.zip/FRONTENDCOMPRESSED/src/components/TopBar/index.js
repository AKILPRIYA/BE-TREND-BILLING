import React from "react";
import { Link } from "react-router-dom";

const TopBar = () => {
  return (
    <div className="bg-gray-800 text-white py-4 px-8 flex justify-between items-center">
      {/* Shop Name */}
      <h1 className="text-2xl font-bold">BE trend</h1>

      {/* Navigation Links */}
      <nav>
        <ul className="flex space-x-6">
          <li>
            <Link to="/" className="hover:text-gray-300">Home</Link>
          </li>
          <li>
            <Link to="/add" className="hover:text-gray-300">Add User</Link>
          </li>
          <li>
            <Link to="/add/addbrand" className="hover:text-gray-300">Add Brand</Link>
          </li>
          <li>
            <Link to="/add/addcolour" className="hover:text-gray-300">Add Colour</Link>
          </li>
          <li>
            <Link to="/add/addarticle" className="hover:text-gray-300">Add Article</Link>
          </li>
          <li>
            <Link to="/delete" className="hover:text-gray-300">Sales</Link>
          </li>
          <li>
            <Link to="/stock" className="hover:text-gray-300">Stock</Link>
          </li>
          <li>
            <Link to="/print" className="hover:text-gray-300">Print Page</Link>
          </li>
          <li>
            <Link to="/barcode" className="hover:text-gray-300">Barcode</Link>
          </li>
        </ul>
      </nav>
    </div>
  );
};

export default TopBar;