import { response } from "express";
import{Dropdown} from "./Dropdown"
import{data} from "./Dropdown";
var url= "http://localhost:8080/api/article/brand/"+selectedBrand+"/"+selectedArticle+"/"+selectedSize;
const response=await axios.get(url);
setData(response.data);
console.log(response.data);
function setData()
{
  return(
    <React.Fragment>
    <div className="container">
      <div className="row">
        <div className="col-md-12">
          <h5>result</h5>
          <table>
            <thead>
              <tr>
                <th>BRAND</th>
                <th>BRAND</th>
                <th>BRAND</th>
                <th>BRAND</th>
                <th>BRAND</th>
                <th>BRAND</th>
                <th>BRAND</th>
              </tr>
            </thead>
            <tbody>
              {data.map((data, index) => (
                <tr key={index}>
                  <td></td>
                  <td>BRAND</td>
                  <td>BRAND</td>
                  <td>BRAND</td>
                  <td>BRAND</td>
                  <td>BRAND</td>
                  <td>BRAND</td>
                </tr>))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </React.Fragment>
  );
}