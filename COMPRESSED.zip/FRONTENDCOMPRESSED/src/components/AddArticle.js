import React,{useState, useEffect} from 'react';
import axios from "axios";
import Select from "react-dropdown-select";
import { useNavigate } from 'react-router-dom';

const AddArticle = () => {
    const [ARTICLE, setArticle] = useState("");
    
    const navigate = useNavigate();
    const [SIZE , setSize] =useState("");
    const [QUANTITY , setQuantity] =useState("");
    const [MRP , setMRP] =useState("");
    const[users, setUser] = useState("");
    const[colour, setColour] = useState("");
    const[selectedBrand,setSelectedBrand] = useState("");
    const[selectedColour,setSelectedColour] = useState("");
    useEffect(()=>{
        getUsers();getColour();
    },[]);
    
    const updateUser = async (e) =>{
        e.preventDefault();
        try{
         const response=   await axios.post(`http://localhost:8080/api/article/post`,{
                ARTICLE,selectedBrand,SIZE,selectedColour,QUANTITY,MRP
            }) ;   if (response.status === 200) {
                alert('Size added successfully');
              }
            navigate("/add");
        
        }catch(error){
            alert('ERROR');
            console.log(error);
        }
    };
    const onColourClick = async (colour) =>{
        if(colour!==undefined){
        setSelectedColour(colour.idCOLOUR); 
        }
      };
      
    const onBrandClick = async (brand) =>{
        if(brand!==undefined){
        setSelectedBrand(brand.idBRAND);
        console.log(brand.idBRAND); 
        }
      };
    const getUsers = async()=>{
        const response= await axios.get("http://localhost:8080/api/brand");
        setUser(response.data);
        return response.data;  
    };const getColour = async()=>{
        const response= await axios.get("http://localhost:8080/api/colour");
        setColour(response.data);
        return response.data;  
    };
  return (
    <table><tr>
    <div className="columns mt-5 is-centered">
        <Select options = {users} labelField="BRAND" valueField="idBRAND" onChange={(e)=>onBrandClick(e[0])} />
        <Select options = {colour} labelField="COLOUR" valueField="idCOLOUR" onChange={(e)=>onColourClick(e[0])} />
        <div className="column is-half">
            <form onSubmit={updateUser}>
                <div className="field">
                    <label className="label">ARTICLE</label>
                    <div className="control">
                        <input type="text" className="input"
                        value={ARTICLE}
                        onChange={(e)=> setArticle(e.target.value)}
                         placeholder='ARTICLE'/>
                    </div>
                </div>
                <div className="field">
                    <label className="label">SIZE</label>
                    <div className="control">
                        <input type="number" className="input"
                        value={SIZE}
                        onChange={(e)=> setSize(e.target.value)}
                         placeholder='SIZE'/>
                    </div>
                </div>
                <div className="field">
                    <label className="label">QUANTITY</label>
                    <div className="control">
                        <input type="number" className="input"
                        value={QUANTITY}
                        onChange={(e)=> setQuantity(e.target.value)}
                         placeholder='QUANTITY'/>
                    </div>
                </div>
                <div className="field">
                    <label className="label">MRP</label>
                    <div className="control">
                        <input type="number" className="input"
                        value={MRP}
                        onChange={(e)=> setMRP(e.target.value)}
                         placeholder='MRP'/>
                    </div>
                </div>
                <div className="field">
                    <button type="submit" className="button is-success">
                       Update
                    </button>
                </div>
            </form>
        </div>
    </div></tr></table>
  )
}

export default AddArticle