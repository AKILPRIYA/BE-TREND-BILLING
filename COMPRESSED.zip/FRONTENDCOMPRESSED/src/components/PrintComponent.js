import React from 'react';
import { useLocation } from 'react-router-dom';
import ReactToPrint from 'react-to-print';
import './PrintPage.css'; // Add a CSS file to style the print page

const PrintComponent = React.forwardRef((props, ref) => (
    <div ref={ref} className="print-container p-4 bg-white border border-gray-300 rounded shadow-lg">
      <h6 className="text-2xl text-center font-semibold">Be Trend</h6>
      <h6 className="text-md text-center font-semibold"> The Fashion Store</h6>

      <p className="text-xs text-center text-gray-700">3-5, PAPPAMPATTI PIRIVU</p>
      <p className="text-xs text-center text-gray-700">COIMBATORE-103</p>


      <div className="mt-2 mb-2 left-0">
        <p className="text-lg">Customer Name: <span className="font-semibold">{props.customerName}</span></p>
        <p className="text-lg">Phone Number: <span className="font-semibold">{props.phoneNumber}</span></p>
      </div>

      <ul className="list-disc list-inside mb-6">
        {props.products.map((product, index) => (
          <li key={index} className="text-lg">
            {product.brand} - {product.Article} - {product.Size} - {product.Colour} - ₹{product.mrp}
          </li>
        ))}
      </ul>
      <h6 className="text-md font-semibold mb-2">Actual Amount: <span className="text-red-600">₹{props.sum}</span></h6>

      {props.discountedValues>0 &&<h6 className="text-md font-semibold mb-2">Discounted Amount: <span className="text-red-600">₹{props.discountedValues.toFixed(2)}</span></h6>}
      <h2 className="total-value text-2xl font-bold text-center">Total: <span className="text-green-600">₹{props.totalValue.toFixed(2)}</span></h2>
    </div>
));

function PrintPage() {
    const location = useLocation();
    const { products, name, phone, sum1,discountedValues,sum } = location.state || { products: [], name: '', phone: '', sum1: 0 ,sum:0};
    const componentRef = React.useRef();

    return (
        <div>
            <ReactToPrint
                trigger={() => <button>Print</button>}
                content={() => componentRef.current}
            />
            <PrintComponent ref={componentRef} products={products} customerName={name} totalValue={sum1} phoneNumber={phone} discountedValues={discountedValues} sum={sum} />
        </div>
    );
}

export default PrintPage;
