
import axios from "axios";
import { useNavigate, useParams } from 'react-router-dom';
import React, { useState, useEffect, useRef } from "react";
import Select from "react-dropdown-select";
import ReactToPrint from 'react-to-print';
import PrintComponent from './PrintComponent';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import { Link } from 'react-router-dom';
import UserList from "./UserList";

const DeleteUser = ({ placeHolder }) => {
  const [scannedValue, setScannedValue] = useState('');

  const billRef = useRef();
  const navigate = useNavigate();
  const [brands, setBrands] = useState([]);
  const [Brand, setBrand] = useState(null);
  const [Article, setarticle] = useState(null);
  const [Colour, setcolour] = useState(null);
  const [Size, setsize] = useState(null);
  const [mrpData, setMrpData] = useState([]);
  const [mrpData1, setMrpData1] = useState([]);
  const [rowsData, setRowsData] = useState([]);
  const [name, setName] = useState('');
  const [scannedArticle, setscannedArticle] = useState(false);
  const [phone, setPhone] = useState('');
  const [users, setUser] = useState("");
  const [QUANTITY, setQuantity] = useState([]);
  const [sizes, setSize] = useState("");
  const [article, setArticle] = useState("");
  const [colour, setColour] = useState([]);
  const [selectedBrand, setSelectedBrand] = useState(null);
  const [selectedSize, setSelectedSize] = useState(null);
  const [idquantity, setidquantity] = useState([]);
  const [idsize, setidsize] = useState(null);
  const [message, setMessage] = useState('');
  const [error, setError] = useState('');
  const [isDisabled, setIsDisabled] = useState(false);
  const [selectedArticle, setSelectedArticle] = useState(null);
  const [selectedColour, setSelectedColour] = useState(null);
  const [discount, setDiscount] = useState(0);
  const componentRef = useRef();
  const inputRef = useRef(null);
  const [shouldAddRow, setShouldAddRow] = useState(false);



  useEffect(() => {
    getUsers(); getArticle(); getColour();
    const inputField = document.getElementById('scanner-input');
    if (inputField) {
      inputField.focus();
    }
  }, []);

  const saveUser = async (e) => {
    e.preventDefault(); console.log(sum1);
    try {
      const response = await axios.patch('http://localhost:8080/api/quantity/', { rowsData, sum1, name, phone },
        {
          headers: {
            'Content-Type': 'application/json'
          }
        }); console.log('Response:', response.status);
      if (response.status == 200) {
        setMessage(response.data.message);
        setError('');
        // Print products if no error

        setTimeout(() => {
          console.log('Products after update:', discountedValues);
          navigate('/print', { state: { products: response.data.products, sum1, name, phone, discountedValues,sum } });
        }, 1000); alert('printed');
      } else {
        setError('Unexpected response format');
      }
      navigate('/');
    } catch (error) {
      alert('error');
      setError(error.response.data.error);
      setMessage('');
      console.error('Error adding the bill:', error);
    }
  }
  const onItemClick = async (size) => {
    if (size !== undefined) {
      setSelectedSize(size.idSIZE);
      setsize(size.SIZE);
      const response1 = await axios.get("http://localhost:8080/api/quantity/" + selectedArticle + "/" + size.idSIZE + "/" + selectedColour);
      setidquantity(response1.data.idQUANTITY);
      const res1 = await axios.get("http://localhost:8080/api/mrp/" + response1.data.idQUANTITY);
      setMrpData(res1.data.MRP);
      setidsize(response1.data.idSIZE);
    }
  };
  const onColourClick = async (colour) => {
    if (colour !== undefined) {
      setSelectedColour(colour.idCOLOUR);
      setcolour(colour.COLOUR);
      const response1 = await axios.get("http://localhost:8080/api/size/" + selectedArticle + "/" + colour.idCOLOUR);
      setSize(response1.data);
      return response1;
    }
  };
  const onBrandClick = async (brand) => {
    if (brand !== undefined) {
      setSelectedBrand(brand.idBRAND);
      setBrand(brand.BRAND);
      const response1 = await axios.get("http://localhost:8080/api/article/" + brand.idBRAND);
      setArticle(response1.data);
      return response1.data;
    }
  };
  const onArticleClick = async (article) => {
    if (article !== undefined) {
      setSelectedArticle(article.idARTICLE);
      setarticle(article.ARTICLE);
    }
  };
  const getUsers = async () => {
    const response = await axios.get("http://localhost:8080/api/brand");
    setUser(response.data);
    return response.data;
  };
  const getSizes = async () => {
    const response = await axios.get("http://localhost:8080/api/size");
    setSize(response.data);
    return response.data;
  }; const handleDelete = (id) => {
    const newData = [...rowsData];
    newData.splice(id, 1);
    setRowsData(newData);
  };
  const getColour = async () => {
    const response = await axios.get("http://localhost:8080/api/colour/");
    setColour(response.data);
    return response.data;
  }; const getArticle = async () => {
    const response = await axios.get("http://localhost:8080/api/article/");
    setArticle(response.data);
    return response.data;
  }; const getUserById = async () => {
    const response = await axios.get("http://localhost:8080/api/quantity/" + selectedArticle + "/" + selectedSize + "/" + selectedColour);
    return response;
  }; const handleDiscountChange = (e, id) => {
    console.log(e.target.value);
    if (e.target.value == undefined || isNaN(e.target.value) || e.target.value == "" || Number(e.target.value) > 100 || Number(e.target.value) < 0) {
      return;
    }
    const updatedRows = rowsData.map((row, index) => {
      console.log("index: ", index);
      console.log("id: ", id);
      if (index === id) {
        console.log("Row: ", index);
        console.log("Row: ", row);
        // Return a new object with the updated discount value
        let discountedValue = Number(row.mrp) * (1 - Number(e.target.value) / 100);
        return { ...row, discount: e.target.value, discountedValue: discountedValue };
      }
      return row; // Return the row as is if it doesn't match the id
    });

    setRowsData(updatedRows);

    setDiscount(parseFloat(e.target.value));
  }; 
 
  const handleKeyPress = (e) => {
    if (e.key === 'Enter' && scannedValue.trim()) {
      processScannedValue(scannedValue.trim());
      setScannedValue('');
    }
  };
  const [rows, initRow] = useState([]);
  const addTableRows = () => {
   // alert('in table add rows')
    let discountedValue = Number(mrpData * (1 - 0 / 100));
    let obj = {
      users: selectedBrand,
      article: selectedArticle,
      sizes: selectedSize,
      colour: selectedColour,
      idquantity: idquantity,
      mrp: mrpData,
      brand: Brand,
      Article: Article,
      Colour: Colour,
      Size: Size,
      discount: 0,
      discountedValue: discountedValue

    }; setIsDisabled(true);
    setRowsData([...rowsData, obj])
    setSelectedBrand(null);
    setSelectedArticle(null);
    setSelectedSize("");
    setSelectedColour(null);
    setMrpData1([...mrpData1, mrpData]);
    setMrpData([]);
  };
  const handleInputChange = (e) => {
    setScannedValue(e.target.value);
  };
  useEffect(() => {
    // Check if all necessary states are set before calling addTableRows
    if (shouldAddRow ) {
      addTableRows();
      setShouldAddRow(false); // Reset the flag
    }
  }, [shouldAddRow, selectedBrand, selectedArticle, selectedSize, selectedColour, idquantity]);
  const processScannedValue = async (value) => {
    console.log(value);
    const idbrand = value.split('-')[0].trim();
    const idarticle = value.split('-')[1].trim();
    const colours = value.split('-')[3].trim();
    const idsize = value.split('-')[2].trim().toString();
    const idmrp = value.split('-')[4].trim().toString();
    const brand = users.find(b => b.BRAND === idbrand);
    if (brand) {
      const response1 = await axios.get("http://localhost:8080/api/article/" + brand.idBRAND); setSelectedBrand(brand.idBRAND); setBrand(brand.BRAND);
      const Articl = response1.data.find(a => a.ARTICLE === idarticle); setSelectedArticle(Articl.idARTICLE); setarticle(Articl.ARTICLE);
      const idcolour = colour.find(c => c.COLOUR === colours); setSelectedColour(idcolour.idCOLOUR); setcolour(idcolour.COLOUR);
      if (idcolour) {
        const response1 = await axios.get("http://localhost:8080/api/size/" + Articl.idARTICLE + "/" + idcolour.idCOLOUR); console.log(response1.data);
        const siz = response1.data.find(s => s.SIZE.toString() === idsize.toString()); setsize(siz.SIZE);
        const response2 = await axios.get("http://localhost:8080/api/mrp/" + siz.idSIZE);
        const mrp1 = response2.data.find(m => m.MRP.toString() === idmrp.toString());
        const response = await axios.get("http://localhost:8080/api/quantity/" + mrp1.idMRP);
        setidquantity(response.data[0].idQUANTITY); setMrpData(idmrp);
        setidsize(response1.data.idSIZE);
        setscannedArticle(true);
        setShouldAddRow(true);
      }
    } else {
      console.error("Scanned brand not found");
    }
    // Filter out any invalid entries
    setError('');
  };
  console.log(mrpData1);
  const sum = mrpData1.reduce((acc, curr) => Number(acc) + Number(curr), 0);
  const discountedValues = Math.ceil(rowsData.reduce((acc, curr) => Number(acc) + (Number(curr.mrp) - Number(curr.discountedValue)), 0).toFixed(2));
  const sum1 = rowsData.reduce((acc, curr) => Number(acc) + Number(curr.discountedValue), 0);
  console.log("rowsData", rowsData);
  console.log("discountedValues", discountedValues);
  return (

    <> <div >
      <div className="flex items-center space-x-4">
        <div className="flex flex-col">
          <label className="mb-1">Name:</label>
          <input
            type="text"
            value={name}
            onChange={(e) => setName(e.target.value)}
            required
            className="border p-2 rounded"
          />
        </div>
        <div className="flex flex-col">
          <label className="mb-1">Phone:</label>
          <input
            type="tel"
            value={phone}
            onChange={(e) => setPhone(e.target.value)}
            required
            className="border p-2 rounded"
          />
        </div>
        <div className="flex flex-col">
          <label className="mb-0">Scan:</label>

          <input
            ref={inputRef}
            type="text"
            value={scannedValue}
            onChange={handleInputChange}
            onKeyPress={handleKeyPress}
            placeholder="Scan values separated by commas"
            autoFocus
          />
        </div>
        {/* <div className="flex flex-col">
          <label className="mb-1">Add:</label>
          {error && <div style={{ color: 'red' }}>{error}</div>}
          <button className="btn btn-outline-success" onClick={addTableRows} disabled={idquantity == null} >+</button></div> */}

      </div>
    </div>
      <div className="flex items-center space-x-4 p-2">
        <Select
          searchable={true}
          sortBy="BRAND"
          searchBy="BRAND"
          options={users}
          labelField="BRAND"
          valueField="idBRAND"
          onChange={(values) => onBrandClick(values[0])}
          className=" w-2 h-10 border p-1 rounded"
        />

        <Select
          searchable={true}
          searchBy="ARTICLE"
          options={article}
          labelField="ARTICLE"
          valueField="idARTICLE"
          onChange={(values) => onArticleClick(values[0])}
          className="w-2 h-10 border p-2 rounded"
        />

        <Select
          searchable={true}
          searchBy="COLOUR"
          options={colour}
          labelField="COLOUR"
          valueField="idCOLOUR"
          onChange={(values) => onColourClick(values[0])}
          className="w-2 h-10 border p-2 rounded"
        />

        <Select
          searchable={true}
          searchBy="SIZE"
          options={sizes}
          labelField="SIZE"
          valueField="idSIZE"
          onChange={(values) => onItemClick(values[0])}
          className="w-2 h-10 border p-2 rounded"
        />

        <button
          className="border border-green-500 text-green-500 rounded px-4 py-2 hover:bg-green-500 hover:text-white transition"
          onClick={addTableRows}
          disabled={idquantity == null}
        >
          +
        </button>
      </div>
      <div className="flex items-center space-x-4 p-2">

        <table>
          <thead>
            <tr>
              <th>BRAND</th>
              <th>ARTICLE</th>
              <th>SIZE</th>
              <th>COLOUR</th>
              <th>MRP</th>
              <th>Discounted Value</th>
              <th>Discounted</th>
              <th className="border border-gray-300 p-2">Actions</th>
            </tr>
          </thead>
          <tbody>
            {rowsData.map((data, index) => (
              <tr key={index}>

                <td>{data.brand}</td>
                <td>{data.Article}</td>
                <td>{data.Size}</td>
                <td>{data.Colour}</td>
                <td>{data.mrp}</td>
                <td>{data.discountedValue.toFixed(2)}</td>
                <td><input type="number" value={data.discount} onChange={(e) => handleDiscountChange(e, index)} placeholder="Enter discount percentage" /></td>
                <td><button onClick={() => handleDelete(data.index)}>-</button></td>
              </tr>))}
          </tbody>
          <tfoot>
          <tr className="bg-gray-100 font-bold">
            <td colSpan="4" className="border border-gray-300 p-2 text-right">Total</td>
            <td className="border border-gray-300 p-2">{sum.toFixed(2)}</td>
            <td className="border border-gray-300 p-2">{sum1.toFixed(2)}</td>
            <td className="border border-gray-300 p-2">{discountedValues.toFixed(2)}</td>
            <td className="border border-gray-300 p-2" colSpan="2"></td>
          </tr>
        </tfoot>
        </table>
      </div>
      <div className="flex flex-col space-y-4 p-4 max-w-lg mx-auto">
  {/* <div className="flex justify-between items-center space-x-4">
    <p className="font-semibold">SUM: {sum}</p>
    <input
      type="number"
      value={discount}
      onChange={handleDiscountChange}
      placeholder="Enter discount percentage"
      className="border p-2 rounded w-1/2"
    />
  </div> */}

  {/* <ul className="space-y-2">
    {rowsData.map((value, index) => (
      <li key={index} className="text-sm">
        <span className="font-semibold">Original:</span> {value.mrp}, 
        <span className="font-semibold"> Discounted:</span> {value.discountedValue}
      </li>
    ))}
  </ul> */}

  {/* <p className="text-lg font-bold text-right">{sum1.toFixed(0)}</p> */}

  <div className="flex flex-col items-center space-y-2">
    <button
      type="submit"
      className="bg-green-500 text-white py-2 px-4 rounded hover:bg-green-600"
      onClick={saveUser}
    >
      Save
    </button>

    {message && <div className="text-green-500">{message}</div>}
    {error && <div className="text-red-500">{error}</div>}
  </div>
</div>
    </>);
};
export default DeleteUser;