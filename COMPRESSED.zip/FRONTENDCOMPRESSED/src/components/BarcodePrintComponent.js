import React, { useState, useRef, useEffect } from 'react';
import ReactToPrint from 'react-to-print';
import JsBarcode from 'jsbarcode';

// Barcode component with ref for printing
const BarcodeComponent = React.forwardRef((props, ref) => {
  const barcodeRef = useRef();

  useEffect(() => {
    // Generate barcode when the component is rendered
    if (props.barcodeValue) {
      JsBarcode(barcodeRef.current, props.barcodeValue, {
        format: 'CODE128',
        width: .8,
        height: 40,
        displayValue: true,
        fontSize: 5,
      });
    }
  }, [props.barcodeValue]);

  return (
    <div
      ref={ref}
      style={{
        width: '50mm',
        padding: '5mm',
        display: 'flex',
        flexWrap: 'wrap',
        justifyContent: 'space-between',
        textAlign:'left',
      }}
    >
      <div
        style={{
          width: '48mm', // Ensure space for labels
          height: '23mm', // Adjust for height of label
          textAlign: 'center', // Optional border
          margin: '1mm', // Margin to prevent overlap
          padding: '2mm', 
          display: 'inline-block',
          textAlign: 'left', // Allows side by side layout
        }}
      >
        {/* Render the barcode */}
        <svg ref={barcodeRef}></svg>
        {/* Display MRP below the barcode */}
        <p style={{ fontSize: '8px', margin: '0', marginTop: '1mm' }}>
          MRP: ₹{props.mrp}
        </p>
      </div>
    </div>
  );
});

// Main component to handle barcodes
const PrintBarcodes = () => {
  const [barcodeValue, setBarcodeValue] = useState('');
  const [mrp, setMrp] = useState('');
  const [barcodes, setBarcodes] = useState([]);
  const componentRef = useRef();

  const handleAddBarcode = () => {
    // Add the input barcode and MRP to the list
    if (barcodeValue[0] && mrp[0] && barcodeValue[1] && mrp[1]) {
      setBarcodes([...barcodes, { barcodeValue, mrp }]);
      setBarcodeValue('');
      setMrp('');
    }
  };

  return (
    <div>
      <div>
        {/* Input fields for barcode and MRP */}
        <input
          type="text"
          placeholder="Enter Barcode"
          value={barcodeValue}
          onChange={(e) => setBarcodeValue(e.target.value)}
        />
        <input
          type="number"
          placeholder="Enter MRP"
          value={mrp}
          onChange={(e) => setMrp(e.target.value)}
        />
        <button onClick={handleAddBarcode}>Add Barcode</button>
      </div>

      {/* Display barcodes and print them */}
      <ReactToPrint
        trigger={() => <button>Print Barcodes</button>}
        content={() => componentRef.current}
      />

      <div ref={componentRef}
       style={{
        display: 'flex', // Use flexbox to align barcodes side by side
        flexWrap: 'wrap', // Ensure wrapping if more than 2 barcodes
        justifyContent: 'flex-start', // Align barcodes to the start
        width: '100mm', // Total width for two barcodes (50mm each)
        gap: '2mm', // Gap between two barcodes for spacing // Space out items
      }} >
        {barcodes.map((item, index) => (
          <BarcodeComponent
            key={index}
            barcodeValue={item.barcodeValue}
            mrp={item.mrp}
          />
          
        ))}
      </div>
    </div>
  );
};

export default PrintBarcodes;
