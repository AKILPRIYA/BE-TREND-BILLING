import React from 'react';

function saveUser(data) {
  return (
    <div>
      <React.Fragment>
        <div className="container">
          <div className="row">
            <div className="col-md-12">
              <h5>result</h5>
              <table>
                <thead>
                  <tr>
                    <th>BRAND</th>
                    <th>BRAND</th>
                    <th>BRAND</th>
                    <th>BRAND</th>
                    <th>BRAND</th>
                    <th>BRAND</th>
                    <th>BRAND</th>
                  </tr>
                </thead>
                <tbody>
                  {data.map((data, index) => (
                    <tr key={index}>
                      <td></td>
                      <td>BRAND</td>
                      <td>BRAND</td>
                      <td>BRAND</td>
                      <td>BRAND</td>
                      <td>BRAND</td>
                      <td>BRAND</td>
                    </tr>))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </React.Fragment></div>
  );
}
